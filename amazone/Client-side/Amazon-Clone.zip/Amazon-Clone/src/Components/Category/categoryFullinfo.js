export const categoryInfos = [
  {
    id: 1,
    title: "Electronics",
    name: "electronics",
    imageLink: "https://fakestoreapi.com/img/81QpkIctqPL._AC_SX679_.jpg",
  },

  {
    id: 2,
    title: "Descover fashion trends",
    name: "women's clothing",
    imageLink: "https://fakestoreapi.com/img/51Y5NI-I5jL._AC_UX679_.jpg",
  },

  {
    id: 3,
    title: "White Gold Plated Princess",
    name: "jewelery",
    imageLink:
      "https://fakestoreapi.com/img/71YAIFU48IL._AC_UL640_QL65_ML3_.jpg",
  },

  {
    id: 4,
    title: "Men's clothing",
    name: "men's clothing",
    imageLink:
      "https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg",
  },
];
