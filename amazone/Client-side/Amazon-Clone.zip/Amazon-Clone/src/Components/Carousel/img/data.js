import img1 from './1001.jpg'
import img2 from './1002.jpg'
import img3 from './1003.jpg'
import img4 from './1004.jpg'
import img5 from './1005.jpg'
import img6 from './1006.jpg'
import img7 from './1007.jpg'

export const img = [img1, img2, img3, img4, img5, img6, img7]