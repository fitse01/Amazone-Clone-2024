import React from 'react'
import classes from "./Payment.module.css"
import LayOut from '../../Components/LayOut/LayOut'

function Payment() {
  return (
    <LayOut>
      <div>Payment</div>
    </LayOut>
    
  )
}

export default Payment