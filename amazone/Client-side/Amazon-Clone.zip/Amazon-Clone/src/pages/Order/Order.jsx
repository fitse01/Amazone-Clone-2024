import React from 'react'
import classes from'./Order.css'
import LayOut from '../../Components/LayOut/LayOut'

function Order() {
  return (
    <LayOut>
      <div>Order</div>
    </LayOut>
    
  )
}

export default Order